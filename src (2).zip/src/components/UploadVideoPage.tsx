import { useEffect, useMemo, useState } from "react";
import {
  Upload,
  FileVideo,
  CheckCircle,
  AlertCircle,
  Play,
  Trash2,
  Package,
  ShieldAlert,
} from "lucide-react";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

async function uploadToBackend(file: File) {
  const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

  const form = new FormData();
  form.append("file", file);

  const res = await fetch(`${API_BASE}/api/offline/upload`, {
    method: "POST",
    body: form,
  });

  const text = await res.text(); // <-- IMPORTANT
  console.log("upload status:", res.status, "body:", text);

  if (!res.ok) throw new Error(`Upload failed: ${res.status}`);

  // parse JSON safely
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("Backend returned non-JSON response");
  }
}

type AnalysisMode = "lost-found" | "attire";
type VideoStatus = "processing" | "ready" | "failed";

type UploadedVideo = {
  id: string;
  name: string;
  size: string;
  duration: string;
  uploadDate: Date;
  status: "ready" | "processing" | "failed";
  backendPath?: string; // add this
};

type Severity = "Low" | "Medium" | "High";

interface DetectionRecord {
  id: string;
  videoId: string;
  videoName: string;
  mode: AnalysisMode;
  cameraCode?: string; // optional if you want later
  location?: string; // optional if you want later
  label: string; // object type OR violation label
  severity: Severity;
  timestamp: Date;
}

interface UploadVideoPageProps {
  onProcessingComplete?: () => void;
}

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(16).slice(2, 10)}`;
}

export function UploadVideoPage({ onProcessingComplete }: UploadVideoPageProps) {
  const MODE_STORAGE_KEY = "upload:offlineMode";
  const [mode, setMode] = useState<AnalysisMode>(() => {
    const saved = localStorage.getItem(MODE_STORAGE_KEY);
    return saved === "lost-found" || saved === "attire" ? saved : "attire"; 
  });

  useEffect(() => {
    localStorage.setItem(MODE_STORAGE_KEY, mode); // remember last clicked tab
  }, [mode]);

  const [dragActive, setDragActive] = useState(false);

  const [uploadedVideos, setUploadedVideos] = useState<UploadedVideo[]>([]);

  const refreshVideos = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/offline/videos`);
      if (!res.ok) throw new Error("Failed to load videos");
      const data = await res.json();

      setUploadedVideos(
        (data ?? []).map((v: any) => ({
          ...v,
          uploadDate: new Date(v.uploadDate),
        }))
      );
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    refreshVideos();
  }, []);

  useEffect(() => {
    const hasProcessing = uploadedVideos.some((v) => v.status === "processing");
    if (!hasProcessing) return;

    const t = setInterval(() => {
      refreshVideos();
    }, 15000);

    return () => clearInterval(t);
  }, [uploadedVideos]);

  const totalSizeLabel = useMemo(() => {
    const totalMB = uploadedVideos.reduce((sum, v) => {
      const m = String(v.size).match(/([\d.]+)\s*MB/i);
      return sum + (m ? parseFloat(m[1]) : 0);
    }, 0);
    return `${Math.round(totalMB)} MB`;
  }, [uploadedVideos]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") setDragActive(true);
    if (e.type === "dragleave") setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const isValidVideoFile = (file: File) => {
    // basic validation (extend if needed)
    const okMime = file.type.startsWith("video/");
    const okExt = /\.(mp4|avi|mov|mkv)$/i.test(file.name);
    return okMime || okExt;
  };

  const handleFiles = async (files: FileList) => {
    const file = files[0];

    // validate format
    if (!isValidVideoFile(file)) {
      alert("Invalid format. Please upload MP4, AVI, MOV, or MKV video.");
      return;
    }

    // show processing immediately
    const tempId = `vid-${Date.now()}`;

    setUploadedVideos((prev) => [
      {
        id: tempId,
        name: file.name,
        size: `${(file.size / (1024 * 1024)).toFixed(0)} MB`,
        duration: "00:00:00",
        uploadDate: new Date(),
        status: "processing",
      },
      ...prev,
    ]);

    try {
      const saved = await uploadToBackend(file);

      // optional: keep this optimistic update (ok to keep)
      setUploadedVideos((prev) =>
        prev.map((v) =>
          v.id === tempId
            ? {
                ...v,
                id: saved.id,
                name: saved.name ?? file.name,
                status: saved.status ?? "ready",
                backendPath: saved.path,
              }
            : v
        )
      );

      // ✅ IMPORTANT: sync with backend list (single source of truth)
      await refreshVideos();
      
    } catch (e) {
      console.error(e);

      setUploadedVideos((prev) =>
        prev.map((v) => (v.id === tempId ? { ...v, status: "failed" } : v)),
      );

      alert("Upload failed. Check backend console.");
    }
  };

  const handleDelete = async (videoId: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/offline/videos/${videoId}`, { method: "DELETE" });
      const text = await res.text();
      console.log("delete status:", res.status, "body:", text);
      if (!res.ok) throw new Error(`Delete failed: ${res.status}`);
    } catch (e) {
      console.warn("Backend delete failed, removing locally only", e);
    }

    // Always refresh list (backend is source of truth)
    await refreshVideos();
  };


  const getStatusBadge = (status: VideoStatus) => {
    switch (status) {
      case "ready":
        return (
          <div className="flex items-center gap-1.5 text-green-400 bg-green-400/10 px-2 py-1 rounded text-xs">
            <CheckCircle className="w-3 h-3" />
            <span>Ready</span>
          </div>
        );
      case "processing":
        return (
          <div className="flex items-center gap-1.5 text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded text-xs">
            <div className="w-3 h-3 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin" />
            <span>Processing</span>
          </div>
        );
      case "failed":
        return (
          <div className="flex items-center gap-1.5 text-red-400 bg-red-400/10 px-2 py-1 rounded text-xs">
            <AlertCircle className="w-3 h-3" />
            <span>Failed</span>
          </div>
        );
    }
  };

  const processingCount = uploadedVideos.filter((v) => v.status === "processing").length;
  const readyCount = uploadedVideos.filter((v) => v.status === "ready").length;

  return (
    <main className="flex-1 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-white mb-1">Upload Video</h2>
        <p className="text-slate-400">Upload offline CCTV footage for analysis</p>
      </div>

      {/* ✅ Module selector (your “select Lost & Found / Attire” requirement) */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <div className="text-white">Offline Processing Mode</div>
            <div className="text-slate-400 text-sm">
              Choose which module to open in Live View <b>Analyze</b>.
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-800/30 p-1 rounded-lg w-fit">
            <button
              onClick={() => setMode("lost-found")}
              className={`px-5 py-2 rounded-md transition-colors ${
                mode === "lost-found" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              Lost &amp; Found
            </button>
            <button
              onClick={() => setMode("attire")}
              className={`px-5 py-2 rounded-md transition-colors ${
                mode === "attire" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              Attire Compliance
            </button>
          </div>
        </div>
      </div>

      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-12 mb-6 transition-colors ${
          dragActive ? "border-blue-500 bg-blue-500/5" : "border-slate-700 bg-slate-900/30 hover:border-slate-600"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-600/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8 text-blue-400" />
          </div>
          <h3 className="text-white mb-2">Drop video files here</h3>
          <p className="text-slate-400 mb-4">or click to browse from your device</p>

          <label className="inline-block">
            <input type="file" className="hidden" accept="video/*" onChange={handleChange} multiple />
            <span className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg cursor-pointer transition-colors">
              <Upload className="w-4 h-4" />
              Select Files
            </span>
          </label>

          <div className="mt-4 text-sm text-slate-500">Supported: MP4, AVI, MOV, MKV</div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Total Uploaded</div>
          <div className="text-white text-2xl">{uploadedVideos.length}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Processing</div>
          <div className="text-yellow-400 text-2xl">{processingCount}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Ready</div>
          <div className="text-green-400 text-2xl">{readyCount}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Total Size</div>
          <div className="text-white text-2xl">{totalSizeLabel}</div>
        </div>
      </div>

      {/* Uploaded list */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-white">Uploaded Videos</h3>
          <div className="text-slate-400 text-sm">
            Current module:{" "}
            <span className="text-white font-medium">
              {mode === "lost-found" ? "Lost & Found" : "Attire Compliance"}
            </span>
          </div>
        </div>

        <div className="divide-y divide-slate-800">
          {uploadedVideos.length === 0 ? (
            <div className="p-12 text-center">
              <FileVideo className="w-12 h-12 text-slate-700 mx-auto mb-3" />
              <p className="text-slate-500">No videos uploaded yet</p>
            </div>
          ) : (
            uploadedVideos.map((video) => {
              return (
                <div key={video.id} className="p-4 hover:bg-slate-800/30 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-24 h-16 bg-slate-800 rounded flex items-center justify-center flex-shrink-0">
                      <FileVideo className="w-8 h-8 text-slate-600" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-white truncate">{video.name}</h4>
                        {getStatusBadge(video.status)}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-400">
                        <span>{video.size}</span>
                        <span>•</span>
                        <span>{video.duration}</span>
                        <span>•</span>
                        <span>{video.uploadDate.toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {video.status === "ready" && (
                        <button
                          onClick={() => {
                            if (mode === "attire") {
                              localStorage.setItem("attire:liveVideoId", video.id);
                              localStorage.setItem("nav:lastPage", "live-attire");
                            } else {
                              localStorage.setItem("lostfound:liveVideoId", video.id);
                              localStorage.setItem("nav:lastPage", "live-lostfound");
                            }
                            window.dispatchEvent(new Event("storage"));
                          }}
                          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
                        >
                          <Play className="w-4 h-4" />
                          <span>Open Live</span>
                        </button>
                      )}

                      <button
                        onClick={() => handleDelete(video.id)}
                        className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                        title="Delete video"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </main>
  );
}
