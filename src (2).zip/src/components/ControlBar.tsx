import { Grid3x3, Maximize2, Search, SlidersHorizontal, Download } from 'lucide-react';

export function ControlBar() {
  return (
    <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
      <div className="flex items-center justify-between">
        {/* View Controls */}
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg transition-colors">
            <Grid3x3 className="w-4 h-4" />
            <span>Grid View</span>
          </button>
          <button className="flex items-center gap-2 bg-slate-800/50 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-lg transition-colors">
            <Maximize2 className="w-4 h-4" />
            <span>Fullscreen</span>
          </button>
        </div>

        {/* Search and Filters */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search cameras..."
              className="bg-slate-800 text-white pl-10 pr-4 py-2 rounded-lg border border-slate-700 focus:border-slate-600 focus:outline-none w-64"
            />
          </div>
          <button className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg transition-colors">
            <SlidersHorizontal className="w-4 h-4" />
            <span>Filters</span>
          </button>
          <button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>
    </div>
  );
}
