//AttireComplianceLiveView.tsx:
import { useEffect, useMemo, useRef, useState } from "react";
import { AlertTriangle, Circle } from "lucide-react";

const API_BASE =
  (import.meta as any).env?.VITE_API_BASE_URL?.replace(/\/$/, "") || "http://127.0.0.1:8000";
const MAX_LIVE = 4;

type Violation = "sleeveless" | "shorts" | "slippers";

type UploadedVideo = {
  id: string;
  name: string;
  uploadDate: string;
  size: string;
};

type RtspSource = { id: string; name: string; url: string };

interface Detection {
  id: string;
  x: number;      // percent
  y: number;      // percent
  width: number;  // percent
  height: number; // percent
  label: string;
  violation?: Violation;
}

async function fetchRtspSourcesSafe(): Promise<RtspSource[]> {
  try {
    const res = await fetch(`${API_BASE}/api/rtsp/sources`);
    if (!res.ok) return [];
    const data = await res.json().catch(() => ({}));
    return (data?.sources || []) as RtspSource[];
  } catch {
    return [];
  }
}

async function fetchRtspDetectionsSafe(
  rtspId: string
): Promise<{ ts: number; fps: number; resolution: [number, number]; detections: Detection[] } | null> {
  try {
    const res = await fetch(`${API_BASE}/api/rtsp/live/${rtspId}/detections`);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function closeRtspSafe(rtspId: string) {
  try {
    await fetch(`${API_BASE}/api/rtsp/close/${rtspId}`, { method: "POST" });
  } catch {}
}

async function fetchEnabledSources(): Promise<Record<string, boolean>> {
  const res = await fetch(`${API_BASE}/api/attire/sources`);
  if (!res.ok) throw new Error("Failed to load enabled sources");
  const data = await res.json();
  return (data?.sources || {}) as Record<string, boolean>;
}

async function fetchUploadedVideos(): Promise<UploadedVideo[]> {
  const res = await fetch(`${API_BASE}/api/offline/videos`);
  if (!res.ok) throw new Error("Failed to load uploaded videos");
  return res.json();
}

async function fetchOfflineDetections(
  videoId: string
): Promise<{ ts: number; fps: number; resolution: [number, number]; detections: Detection[] }> {
  const res = await fetch(`${API_BASE}/api/offline/live/${videoId}/detections`);
  if (!res.ok) throw new Error("Failed to load offline detections");
  return res.json();
}

async function fetchWebcamDetections(): Promise<{
  ts: number;
  fps: number;
  resolution: [number, number];
  detections: Detection[];
}> {
  const res = await fetch(`${API_BASE}/api/live/webcam/detections`);
  if (!res.ok) throw new Error("Failed to load webcam detections");
  return res.json();
}

async function fetchAttireFps(videoId: string): Promise<{ stream_fps: number; detect_fps: number }> {
  const res = await fetch(`${API_BASE}/api/attire/fps/${videoId}`);
  if (!res.ok) throw new Error("Failed to load fps");
  const data = await res.json();
  return {
    stream_fps: Number(data?.stream_fps ?? 12),
    detect_fps: Number(data?.detect_fps ?? 2),
  };
}

async function disableSourceAndRefresh(id: string) {
  await setSourceEnabled(id, false);
  localStorage.setItem("attire:enabledSourcesVer", String(Date.now()));
  window.dispatchEvent(new Event("attire:sourcesChanged"));
}

async function refreshConfiguredFps(videoIds: string[]) {
  const results = await Promise.allSettled(
    videoIds.map(async (id) => ({ id, fps: await fetchAttireFps(id) }))
  );

  const next: Record<string, { stream_fps: number; detect_fps: number }> = {};
  for (const r of results) {
    if (r.status === "fulfilled") next[r.value.id] = r.value.fps;
  }
  return next;
}

async function closeOffline(videoId: string) {
  try {
    await fetch(`${API_BASE}/api/offline/close/${videoId}`, { method: "POST" });
  } catch {}
}

// --- WebCam ---
const WEBCAM_ID = "__webcam__";

async function startWebcam() {
  await fetch(`${API_BASE}/api/live/webcam/start`, { method: "POST" });
}
async function stopWebcam() {
  await fetch(`${API_BASE}/api/live/webcam/stop`, { method: "POST" });
}

async function setSourceEnabled(videoId: string, enabled: boolean) {
  await fetch(`${API_BASE}/api/attire/sources/${videoId}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ enabled }),
  });
}

type GridSource =
  | { kind: "offline"; video: UploadedVideo }
  | { kind: "rtsp"; rtsp: RtspSource }
  | { kind: "webcam" };
// --------------

function getViolationColor(v?: Violation) {
  switch (v) {
    case "sleeveless":
      return "border-orange-500 bg-orange-500/10";
    case "shorts":
      return "border-red-500 bg-red-500/10";
    case "slippers":
      return "border-yellow-500 bg-yellow-500/10";
    default:
      return "border-slate-500/60 bg-slate-500/5"; 
  }
}

function getLabelColor(v?: Violation) {
  switch (v) {
    case "sleeveless":
      return "bg-orange-500 text-white";
    case "shorts":
      return "bg-red-500 text-white";
    case "slippers":
      return "bg-yellow-500 text-black";
    default:
      return "bg-slate-700 text-white";
  }
}

export function AttireComplianceLiveView() {
  const [time, setTime] = useState(new Date());
  const [camDetections, setCamDetections] = useState<Record<string, Detection[]>>({});
  const [camMeta, setCamMeta] = useState<Record<string, { fps: number; resolution: [number, number] }>>({});
  const [videoFps, setVideoFps] = useState<Record<string, { stream_fps: number; detect_fps: number }>>({});
  const [uploadedVideos, setUploadedVideos] = useState<UploadedVideo[]>([]);
  const [rtspSources, setRtspSources] = useState<RtspSource[]>([]);
  const [streamReload, setStreamReload] = useState<Record<string, number>>({});
  const [enabledMap, setEnabledMap] = useState<Record<string, boolean>>({});
  const [selectedVideoId, setSelectedVideoId] = useState<string>(() => {
    return localStorage.getItem("attire:liveVideoId") || "";
  });
  const [isTabVisible, setIsTabVisible] = useState(() => !document.hidden);
  const [showWebcam, setShowWebcam] = useState<boolean>(() => {
    return localStorage.getItem("attire:showWebcam") === "1";
  });
  const liveVideos = useMemo(() => {
    if (!uploadedVideos.length) return [];

    const isEnabled = (id: string) => enabledMap[id] ?? true;
    const enabledVideos = uploadedVideos.filter(v => isEnabled(v.id));

    const selected =
      selectedVideoId && isEnabled(selectedVideoId)
        ? enabledVideos.find(v => v.id === selectedVideoId)
        : undefined;

    const rest = enabledVideos.filter(v => v.id !== selected?.id);
    const ordered = selected ? [selected, ...rest] : enabledVideos;

    const slots = showWebcam ? (MAX_LIVE - 1) : MAX_LIVE;
    return ordered.slice(0, Math.max(0, slots));
  }, [uploadedVideos, selectedVideoId, enabledMap, showWebcam]);

  useEffect(() => {
    const uploaded = uploadedVideos.length;
    const webcamOption = 1;
    const rtspOption = rtspSources.length;

    const total = uploaded + webcamOption + rtspOption;
    localStorage.setItem("attire:totalSources", String(total));
    window.dispatchEvent(new Event("storage"));
  }, [uploadedVideos, rtspSources]);

  useEffect(() => {
    let alive = true;

    const load = async () => {
      const list = await fetchRtspSourcesSafe();
      if (alive) setRtspSources(list);
    };

    load();
    const t = window.setInterval(load, 5000);

    return () => {
      alive = false;
      window.clearInterval(t);
    };
  }, []);

  const prevLiveIdsRef = useRef<string[]>([]);
  const prevRtspIdsRef = useRef<string[]>([]);

  // --- RTSP , Webcam, offline ---
  const gridSources: GridSource[] = useMemo(() => {
    const items: GridSource[] = [];

    // webcam first (optional)
    if (showWebcam) items.push({ kind: "webcam" });

    // offline videos
    for (const v of liveVideos) items.push({ kind: "offline", video: v });

    // rtsp sources (enabled only)
    const isEnabled = (id: string) => enabledMap[id] ?? true;
    const enabledRtsp = (rtspSources || []).filter(s => isEnabled(s.id));
    for (const s of enabledRtsp) items.push({ kind: "rtsp", rtsp: s });

    return items.slice(0, MAX_LIVE);
  }, [showWebcam, liveVideos, rtspSources, enabledMap]);

  // Header: Tell App.tsx how many sources are currently active (ACTUALLY shown)
  useEffect(() => {
  const ids = gridSources.map((s) => {
      if (s.kind === "webcam") return WEBCAM_ID;
      if (s.kind === "offline") return s.video.id;
      return s.rtsp.id;
    });
    localStorage.setItem("attire:enabledCameraIds", JSON.stringify(ids));
    window.dispatchEvent(new Event("storage"));
  }, [gridSources]);

  useEffect(() => {
    localStorage.setItem("attire:showWebcam", showWebcam ? "1" : "0");
  }, [showWebcam]);

  useEffect(() => {
    if (!showWebcam) return;
    if (!isTabVisible) return;

    let cancelled = false;

    (async () => {
      try {
        await startWebcam();
      } catch {}
    })();

    return () => {
      cancelled = true;
      // stop when leaving page / turning off
      stopWebcam().catch(() => {});
    };
  }, [showWebcam, isTabVisible]);

  // poll webcam detections
  useEffect(() => {
    if (!showWebcam || !isTabVisible) return;

    let stopped = false;

    const pollOnce = async () => {
      try {
        const data = await fetchWebcamDetections();
        if (stopped) return;

        setCamDetections((prev) => ({
          ...prev,
          [WEBCAM_ID]: data.detections ?? [],
        }));

        setCamMeta((prev) => ({
          ...prev,
          [WEBCAM_ID]: {
            fps: data.fps ?? 0,
            resolution: data.resolution ?? [0, 0],
          },
        }));
      } catch {
        // ignore
      }
    };

    pollOnce();
    const t = window.setInterval(pollOnce, 500);

    return () => {
      stopped = true;
      window.clearInterval(t);
    };
  }, [showWebcam, isTabVisible]);

  // -------------
  useEffect(() => {
    const prev = prevLiveIdsRef.current;
    const curr = liveVideos.map(v => v.id);

    // Only close sessions that are no longer in the live grid
    const removed = prev.filter(id => !curr.includes(id));
    removed.forEach(closeOffline);

    prevLiveIdsRef.current = curr;

  }, [liveVideos]);

  useEffect(() => {
    const prev = prevRtspIdsRef.current;
    const curr = (rtspSources || []).filter(s => (enabledMap[s.id] ?? true)).map(s => s.id);

    const removed = prev.filter(id => !curr.includes(id));
    removed.forEach(closeRtspSafe);

    prevRtspIdsRef.current = curr;
  }, [rtspSources, enabledMap]);

  useEffect(() => {
    if (!liveVideos.length) return;

    let cancelled = false;

    (async () => {
      try {
        const results = await Promise.allSettled(
          liveVideos.map(async (v) => {
            const fps = await fetchAttireFps(v.id);
            return { videoId: v.id, fps };
          })
        );

        if (cancelled) return;

        setVideoFps((prev) => {
          const next = { ...prev };
          for (const r of results) {
            if (r.status !== "fulfilled") continue;
            next[r.value.videoId] = r.value.fps;
          }
          return next;
        });
      } catch {
        // ignore
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [liveVideos]);

  useEffect(() => {
    let alive = true;

    const load = async () => {
      try {
        const m = await fetchEnabledSources();
        if (alive) setEnabledMap(m);
      } catch {
        if (alive) setEnabledMap({});
      }
    };

    load();

    const onStorage = (e: StorageEvent) => {
      if (e.key === "attire:enabledSourcesVer") load();
    };

    const onSourcesChanged = () => load();

    window.addEventListener("storage", onStorage);
    window.addEventListener("attire:sourcesChanged", onSourcesChanged);

    return () => {
      alive = false;
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("attire:sourcesChanged", onSourcesChanged);
    };
  }, []);

  useEffect(() => {
    if (!uploadedVideos.length) return;

    const isEnabled = (id: string) => enabledMap[id] ?? true;
    const enabledVideos = uploadedVideos.filter(v => isEnabled(v.id));

    const selected =
      selectedVideoId && isEnabled(selectedVideoId)
        ? enabledVideos.find(v => v.id === selectedVideoId)
        : undefined;

    const rest = enabledVideos.filter(v => v.id !== selected?.id);
    const ordered = selected ? [selected, ...rest] : enabledVideos;

    const slots = showWebcam ? (MAX_LIVE - 1) : MAX_LIVE;

    const overflow = ordered.slice(Math.max(0, slots)).map(v => v.id);
    if (!overflow.length) return;

    (async () => {
      await Promise.allSettled(overflow.map(id => setSourceEnabled(id, false)));

      // force settings + this page to reload enabledMap
      localStorage.setItem("attire:enabledSourcesVer", String(Date.now()));
      window.dispatchEvent(new Event("attire:sourcesChanged"));
    })();
  }, [uploadedVideos, enabledMap, selectedVideoId, showWebcam]);

  // clock
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const onVis = () => setIsTabVisible(!document.hidden);
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  useEffect(() => {
    const onStorage = () => {
      setSelectedVideoId(localStorage.getItem("attire:liveVideoId") || "");
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  // poll offline detections (per uploaded video)
  useEffect(() => {
    if (!isTabVisible) return;

    const rtspEnabled = (rtspSources || []).filter(s => (enabledMap[s.id] ?? true));
    if (!liveVideos.length && rtspEnabled.length === 0) return;

    let stopped = false;

    const pollOnce = async () => {
      try {
        // 1) OFFLINE detections (uploaded videos)
        const offlineResults = await Promise.allSettled(
          liveVideos.map(async (v) => {
            const data = await fetchOfflineDetections(v.id);
            return { id: v.id, data };
          })
        );

        // 2) RTSP detections (enabled only)
        const rtspResults = await Promise.allSettled(
          rtspEnabled.map(async (s) => {
            const data = await fetchRtspDetectionsSafe(s.id);
            return { id: s.id, data };
          })
        );

        if (stopped) return;

        // 3) Merge detections into state (keep webcam too)
        setCamDetections((prev) => {
          const nextDet: Record<string, Detection[]> = {};

          for (const r of offlineResults) {
            if (r.status !== "fulfilled") continue;
            nextDet[r.value.id] = r.value.data.detections ?? [];
          }

          for (const r of rtspResults) {
            if (r.status !== "fulfilled") continue;
            if (!r.value.data) continue; // null means endpoint not ready
            nextDet[r.value.id] = r.value.data.detections ?? [];
          }

          return { ...prev, ...nextDet };
        });

        // 4) Merge meta into state (fps + resolution)
        setCamMeta((prev) => {
          const nextMeta: Record<string, { fps: number; resolution: [number, number] }> = {};

          for (const r of offlineResults) {
            if (r.status !== "fulfilled") continue;
            nextMeta[r.value.id] = {
              fps: r.value.data.fps ?? 0,
              resolution: r.value.data.resolution ?? [0, 0],
            };
          }

          for (const r of rtspResults) {
            if (r.status !== "fulfilled") continue;
            if (!r.value.data) continue;
            nextMeta[r.value.id] = {
              fps: r.value.data.fps ?? 0,
              resolution: r.value.data.resolution ?? [0, 0],
            };
          }

          return { ...prev, ...nextMeta };
        });
      } catch (e) {
        console.warn("poll detections failed:", e);
      }
    };

    pollOnce();
    const t = window.setInterval(pollOnce, 500);

    return () => {
      stopped = true;
      window.clearInterval(t);
    };
  }, [liveVideos, isTabVisible, rtspSources, enabledMap]);

  useEffect(() => {
    (async () => {
      try {
        const vids = await fetchUploadedVideos();
        setUploadedVideos(vids);
        } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  const getSourceId = (src: GridSource) => {
    if (src.kind === "webcam") return WEBCAM_ID;
    if (src.kind === "offline") return src.video.id;
    return src.rtsp.id;
  };

  const totalViolations = useMemo(() => {
    return gridSources.reduce((sum, src) => {
      const id = getSourceId(src);
      return sum + (camDetections[id]?.filter(d => !!d.violation).length ?? 0);
    }, 0);
  }, [gridSources, camDetections]);

  const sleevelessCount = useMemo(() => {
    return gridSources.reduce((sum, src) => {
      const id = getSourceId(src);
      return sum + (camDetections[id]?.filter(d => d.violation === "sleeveless").length ?? 0);
    }, 0);
  }, [gridSources, camDetections]);

  const shortsSlippersCount = useMemo(() => {
    return gridSources.reduce((sum, src) => {
      const id = getSourceId(src);
      return sum + (camDetections[id]?.filter(d => d.violation === "shorts" || d.violation === "slippers").length ?? 0);
    }, 0);
  }, [gridSources, camDetections]);

  return (
    <main className="flex-1 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-white mb-1">Live View - Attire Compliance Monitoring</h2>
            <p className="text-slate-400">Real-time detection of dress code violations</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-slate-400">
              <Circle className="w-2 h-2 fill-green-500 text-green-500 animate-pulse" />
              <span>Live</span>
              <button
                className={`px-3 py-2 rounded-md border text-sm ${
                  showWebcam
                    ? "border-green-600 bg-green-600/20 text-green-200"
                    : "border-slate-700 bg-slate-900/40 text-slate-300"
                }`}
                onClick={() => setShowWebcam((v) => !v)}
              >
                {showWebcam ? "Webcam: ON" : "Webcam: OFF"}
              </button>
            </div>
            <div className="text-slate-400">{time.toLocaleTimeString()}</div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Uploaded Videos</div>
          <div className="text-white text-2xl">{liveVideos.length}</div>
        </div>
        <div className="bg-slate-900/50 border border-red-900/30 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Active Violations</div>
          <div className="text-red-400 text-2xl">{totalViolations}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Sleeveless Detected</div>
          <div className="text-orange-400 text-2xl">{sleevelessCount}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Shorts/Slippers</div>
          <div className="text-yellow-400 text-2xl">{shortsSlippersCount}</div>
        </div>
      </div>

      {/* Legend */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-orange-500 rounded"></div>
            <span className="text-slate-400 text-sm">Sleeveless</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-red-500 rounded"></div>
            <span className="text-slate-400 text-sm">Shorts</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-yellow-500 rounded"></div>
            <span className="text-slate-400 text-sm">Slippers</span>
          </div>
        </div>
      </div>

      {/* Camera Grid */}
      <div className="grid grid-cols-2 gap-4">
        {gridSources.map((src) => {
          if (src.kind === "webcam") {
            const nonce = streamReload[WEBCAM_ID] ?? 0;
            const streamUrl = `${API_BASE}/api/live/webcam/stream?nonce=${nonce}`;
            const detections = camDetections[WEBCAM_ID] ?? [];

            return (
              <div key={WEBCAM_ID} className="bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden">
                <div className="bg-slate-800/50 px-4 py-3 border-b border-slate-700">
                  <div className="text-white font-medium truncate">Laptop Camera</div>
                  <div className="text-slate-400 text-sm truncate">Source: Webcam</div>
                </div>

                <div className="relative aspect-video bg-slate-950 overflow-hidden">
                  <img
                    src={streamUrl}
                    className="absolute inset-0 w-full h-full object-cover"
                    alt="Webcam stream"
                    onError={() => {
                      if (!isTabVisible) return;
                      window.setTimeout(() => {
                        setStreamReload((prev) => ({
                          ...prev,
                          [WEBCAM_ID]: (prev[WEBCAM_ID] ?? 0) + 1,
                        }));
                      }, 500);
                    }}
                  />

                  {/* Webcam boxes */}
                  {detections.map((d) => (
                    <div
                      key={d.id}
                      className={`absolute border-2 ${getViolationColor(d.violation)} pointer-events-none`}
                      style={{ left: `${d.x}%`, top: `${d.y}%`, width: `${d.width}%`, height: `${d.height}%` }}
                    >
                      <div className={`absolute -top-6 left-0 ${getLabelColor(d.violation)} px-2 py-0.5 rounded text-xs`}>
                        {d.label}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-slate-800/30 px-4 py-2 border-t border-slate-700">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Stream: Webcam</span>
                    <button
                      className="text-slate-300 hover:text-white"
                      onClick={() => setShowWebcam(false)}
                      title="Hide webcam"
                    >
                      Hide
                    </button>
                  </div>
                </div>
              </div>
            );
          }

          if (src.kind === "rtsp") {
            const s = src.rtsp;
            const detections = camDetections[s.id] ?? [];
            const nonce = streamReload[s.id] ?? 0;

            // stream endpoint you’ll implement in backend later
            const streamUrl = `${API_BASE}/api/rtsp/stream/${s.id}?nonce=${nonce}`;

            return (
              <div key={s.id} className="bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden">
                <div className="bg-slate-800/50 px-4 py-3 border-b border-slate-700">
                  <div className="text-white font-medium truncate">{s.name}</div>
                  <div className="text-slate-400 text-sm truncate">Source: RTSP</div>
                </div>

                <div className="relative aspect-video bg-slate-950 overflow-hidden">
                  <img
                    src={streamUrl}
                    className="absolute inset-0 w-full h-full object-cover"
                    alt={`RTSP ${s.name}`}
                    onError={() => {
                      if (!isTabVisible) return;
                      window.setTimeout(() => {
                        setStreamReload((prev) => ({ ...prev, [s.id]: (prev[s.id] ?? 0) + 1 }));
                      }, 500);
                    }}
                  />

                  {detections.map((d) => (
                    <div
                      key={d.id}
                      className={`absolute border-2 ${getViolationColor(d.violation)} pointer-events-none`}
                      style={{ left: `${d.x}%`, top: `${d.y}%`, width: `${d.width}%`, height: `${d.height}%` }}
                    >
                      <div className={`absolute -top-6 left-0 ${getLabelColor(d.violation)} px-2 py-0.5 rounded text-xs`}>
                        {d.label}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-slate-800/30 px-4 py-2 border-t border-slate-700">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>Stream: RTSP</span>
                    <button
                      className="text-slate-300 hover:text-white"
                      onClick={async () => {
                        await disableSourceAndRefresh(s.id);
                      }}
                      title="Disable RTSP source"
                    >
                      Disable
                    </button>
                  </div>
                </div>
              </div>
            );
          }

          // offline tile (your existing code)
          const v = src.video;
          const detections = camDetections[v.id] ?? [];
          const fps = videoFps[v.id] ?? { stream_fps: 12, detect_fps: 2 };
          const nonce = streamReload[v.id] ?? 0;

          const params = new URLSearchParams();
          params.set("detect_fps", String(fps.detect_fps));
          params.set("nonce", String(nonce));

          // only include stream_fps if user explicitly overrides (AUTO = 0 or <1)
          const sfps = Number(fps.stream_fps);
          if (Number.isFinite(sfps) && sfps >= 1) {
            params.set("stream_fps", String(sfps));
          }

          const streamUrl = `${API_BASE}/api/offline/stream/${v.id}?${params.toString()}`;

          return (
            <div key={v.id} className="bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden">
              <div className="bg-slate-800/50 px-4 py-3 border-b border-slate-700">
                <div className="text-white font-medium truncate">{v.name}</div>
                <div className="text-slate-400 text-sm truncate">Source: Uploaded Video • {v.size}</div>
              </div>

              <div className="relative aspect-video bg-slate-950 overflow-hidden">
                <img
                  src={streamUrl}
                  className="absolute inset-0 w-full h-full object-cover"
                  alt={`Uploaded video ${v.name}`}
                  onError={() => {
                    if (!isTabVisible) return;
                    window.setTimeout(() => {
                      setStreamReload((prev) => ({ ...prev, [v.id]: (prev[v.id] ?? 0) + 1 }));
                    }, 500);
                  }}
                />

                {detections.map((d) => (
                  <div
                    key={d.id}
                    className={`absolute border-2 ${getViolationColor(d.violation)} pointer-events-none`}
                    style={{ left: `${d.x}%`, top: `${d.y}%`, width: `${d.width}%`, height: `${d.height}%` }}
                  >
                    <div className={`absolute -top-6 left-0 ${getLabelColor(d.violation)} px-2 py-0.5 rounded text-xs`}>
                      {d.label}
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-slate-800/30 px-4 py-2 border-t border-slate-700">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Stream fps: {Number(fps.stream_fps) >= 1 ? fps.stream_fps : "AUTO"}</span>
                  <span>Detection fps: {fps.detect_fps}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Policy */}
      <div className="mt-6 bg-blue-900/20 border border-blue-800 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-blue-300 mb-1">Attire Compliance Policy</div>
            <div className="text-slate-400 text-sm">
              All students must wear appropriate attire in computer labs: sleeved tops (short or long sleeve),
              long trousers, and covered shoes. Violations include sleeveless tops, shorts/skirts, and slippers/sandals.
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
