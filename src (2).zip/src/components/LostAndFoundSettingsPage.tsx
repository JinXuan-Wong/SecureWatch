import { useState, useRef, useEffect } from "react";
import {
  Settings as SettingsIcon,
  Camera,
  Clock,
  Bell,
  Trash2,
  Save,
  RotateCcw,
  Square,
  Circle,
} from "lucide-react";

interface ROI {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface CameraSettings {
  id: string;
  name: string;
  enabled: boolean;
  roi: ROI | null;
}

interface ObjectTypeSettings {
  name: string;
  enabled: boolean;
  icon: string;
}

export function LostAndFoundSettingsPage() {
  const [activeTab, setActiveTab] = useState<
    "roi" | "timing" | "violations" | "notifications"
  >("roi");
  const [selectedCamera, setSelectedCamera] =
    useState<string>("cam-lab-01");
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPoint, setStartPoint] = useState<{
    x: number;
    y: number;
  } | null>(null);
  const [currentROI, setCurrentROI] = useState<ROI | null>(
    null,
  );
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const [cameraSettings, setCameraSettings] = useState<
    CameraSettings[]
  >([
    {
      id: "B001A",
      name: "B001A - Block B - GF - Class A",
      enabled: true,
      roi: { x: 20, y: 15, width: 60, height: 70 },
    },
    {
      id: "B001G",
      name: "B001G - Block B - GF - Class G",
      enabled: true,
      roi: null,
    },
    {
      id: "B100A",
      name: "B100A - Block B - 1F - Class A",
      enabled: true,
      roi: { x: 30, y: 25, width: 50, height: 60 },
    },
    {
      id: "B100D",
      name: "B100D - Block B - 1F - Class D",
      enabled: false,
      roi: null,
    },
    {
      id: "B001H",
      name: "B001H - Block B - GF - Class H",
      enabled: true,
      roi: null,
    },
  ]);

  const [detectionFrequency, setDetectionFrequency] =
    useState(1);
  const [objectTypes, setObjectTypes] = useState<
    ObjectTypeSettings[]
  >([
    { name: "Water Bottle", enabled: true, icon: "💧" },
    { name: "Wallet", enabled: true, icon: "👛" },
    { name: "ID Card", enabled: true, icon: "🪪" },
    { name: "Card Holder", enabled: true, icon: "💳" },
    { name: "Phone", enabled: true, icon: "📱" },
  ]);

  const [notificationsEnabled, setNotificationsEnabled] =
    useState(true);

  const selectedCameraData = cameraSettings.find(
    (cam) => cam.id === selectedCamera,
  );

  useEffect(() => {
    if (selectedCameraData) {
      setCurrentROI(selectedCameraData.roi);
    }
  }, [selectedCamera]);

  useEffect(() => {
    drawCanvas();
  }, [currentROI]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !image) return;

    resizeCanvasToDisplaySize();

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

    if (currentROI) {
      const x = (currentROI.x / 100) * canvas.width;
      const y = (currentROI.y / 100) * canvas.height;
      const width = (currentROI.width / 100) * canvas.width;
      const height = (currentROI.height / 100) * canvas.height;

      ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
      ctx.fillRect(0, 0, canvas.width, y);
      ctx.fillRect(0, y, x, height);
      ctx.fillRect(
        x + width,
        y,
        canvas.width - (x + width),
        height,
      );
      ctx.fillRect(
        0,
        y + height,
        canvas.width,
        canvas.height - (y + height),
      );

      ctx.strokeStyle = "#3b82f6";
      ctx.lineWidth = 3;
      ctx.strokeRect(x, y, width, height);

      const handleSize = 10;
      ctx.fillStyle = "#3b82f6";
      ctx.fillRect(
        x - handleSize / 2,
        y - handleSize / 2,
        handleSize,
        handleSize,
      );
      ctx.fillRect(
        x + width - handleSize / 2,
        y - handleSize / 2,
        handleSize,
        handleSize,
      );
      ctx.fillRect(
        x - handleSize / 2,
        y + height - handleSize / 2,
        handleSize,
        handleSize,
      );
      ctx.fillRect(
        x + width - handleSize / 2,
        y + height - handleSize / 2,
        handleSize,
        handleSize,
      );
    }
  };

  const handleMouseDown = (
    e: React.MouseEvent<HTMLCanvasElement>,
  ) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / canvas.width) * 100;
    const y = ((e.clientY - rect.top) / canvas.height) * 100;

    setIsDrawing(true);
    setStartPoint({ x, y });
  };

  const handleMouseMove = (
    e: React.MouseEvent<HTMLCanvasElement>,
  ) => {
    if (!isDrawing || !startPoint) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / canvas.width) * 100;
    const y = ((e.clientY - rect.top) / canvas.height) * 100;

    const width = x - startPoint.x;
    const height = y - startPoint.y;

    setCurrentROI({
      x: width < 0 ? x : startPoint.x,
      y: height < 0 ? y : startPoint.y,
      width: Math.abs(width),
      height: Math.abs(height),
    });
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
    setStartPoint(null);
  };

  const handleSaveROI = async () => {
    if (!selectedCamera) return;

    // auto-commit current poly if it has >=3 points
    let roisToSave = rois;
    if (currentPoly.length >= 3) {
      roisToSave = {
        ...rois,
        [activeView]: [...(rois[activeView] || []), currentPoly],
      };
      setRois(roisToSave);
      setCurrentPoly([]);
    }

    const res = await fetch(`${API_BASE}/api/attire/roi/${selectedCamera}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rois: roisToSave }),
    });

    if (!res.ok) {
      alert(`Save ROI failed: HTTP ${res.status}`);
      return;
    }
    alert("ROI saved");
  };

  const handleResetROI = () => {
    setCurrentROI(null);
  };

  const handleToggleCamera = (cameraId: string) => {
    setCameraSettings((prev) =>
      prev.map((cam) =>
        cam.id === cameraId
          ? { ...cam, enabled: !cam.enabled }
          : cam,
      ),
    );
  };

  const handleToggleObjectType = (objectName: string) => {
    setObjectTypes((prev) =>
      prev.map((obj) =>
        obj.name === objectName
          ? { ...obj, enabled: !obj.enabled }
          : obj,
      ),
    );
  };

  const resizeCanvasToDisplaySize = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;

    const displayWidth = Math.round(rect.width * dpr);
    const displayHeight = Math.round(rect.height * dpr);

    if (
      canvas.width !== displayWidth ||
      canvas.height !== displayHeight
    ) {
      canvas.width = displayWidth;
      canvas.height = displayHeight;
    }
  };

  const handleSaveSettings = () => {
    alert("All settings saved successfully!");
  };

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      {/* Page Header */}
      <div className="mb-6">
        <h2 className="text-white mb-1">
          Lost & Found Settings
        </h2>
        <p className="text-slate-400">
          Configure Lost & Found detection system
        </p>
      </div>

      {/* Tabs */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg mb-6">
        <div className="flex border-b border-slate-800">
          {[
            {
              id: "roi",
              label: "ROI Configuration",
              icon: Camera,
            },
            {
              id: "timing",
              label: "Timing Control",
              icon: Clock,
            },
            {
              id: "objects",
              label: "Object Categories",
              icon: Square,
            },
            {
              id: "notifications",
              label: "Notifications",
              icon: Bell,
            },
            {
              id: "retention",
              label: "Data Retention",
              icon: Trash2,
            },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-6 py-4 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-blue-500 text-white"
                    : "border-transparent text-slate-400 hover:text-white"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="p-6">
          {/* ROI Configuration Tab */}
          {activeTab === "roi" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-white mb-1">
                  Region of Interest (ROI) Configuration
                </h3>
                <p className="text-slate-400 text-sm">
                  Draw a region on the camera feed to limit
                  object detection to specific areas
                </p>
              </div>

              {/* Camera Selection */}
              <div>
                <label className="block text-slate-400 text-sm mb-2">
                  Select Camera
                </label>
                <select
                  value={selectedCamera}
                  onChange={(e) =>
                    setSelectedCamera(e.target.value)
                  }
                  className="w-full max-w-md bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
                >
                  {cameraSettings.map((cam) => (
                    <option key={cam.id} value={cam.id}>
                      {cam.name} {!cam.enabled && "(Disabled)"}
                    </option>
                  ))}
                </select>
              </div>

              {/* Canvas for ROI Drawing */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-slate-400 text-sm">
                    Draw ROI (Click and drag on the image)
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleResetROI}
                      className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors text-sm"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Reset ROI
                    </button>
                    <button
                      onClick={handleSaveROI}
                      className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm"
                    >
                      <Save className="w-4 h-4" />
                      Save ROI
                    </button>
                  </div>
                </div>

                <div className="relative bg-slate-950 rounded-lg overflow-hidden border border-slate-700 max-w-xl mx-auto">
                  <img
                    ref={imageRef}
                    src="https://s3-ap-southeast-1.amazonaws.com/s3.prod.public.ue.intl/unienrol.com/campus/v2/TAR+UC/PENANG+CAMPUS/Facilities-Amenities/02h_Penang_Branch_TAR_UC_Tanjong_Bungah_Internet_Lab.png"
                    alt="Camera feed"
                    className="absolute inset-0 w-full h-full object-cover opacity-0"
                    onLoad={drawCanvas}
                  />
                  <canvas
                    ref={canvasRef}
                    width={800}
                    height={450}
                    className="w-full cursor-crosshair"
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                  />
                </div>

                <div className="bg-blue-900/20 border border-blue-800 rounded-lg p-3">
                  <p className="text-blue-300 text-sm">
                    💡 Click and drag to draw a rectangular
                    region. Only objects detected within this
                    region will be logged.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Timing Control Tab */}
          {activeTab === "timing" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-white mb-1">
                  Detection Timing Control
                </h3>
                <p className="text-slate-400 text-sm">
                  Configure detection frequency and
                  enable/disable camera feeds
                </p>
              </div>

              {/* Detection Frequency */}
              <div>
                <label className="block text-slate-400 text-sm mb-2">
                  Detection Frequency: Every{" "}
                  {detectionFrequency} second
                  {detectionFrequency !== 1 ? "s" : ""}
                </label>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={detectionFrequency}
                  onChange={(e) =>
                    setDetectionFrequency(
                      parseInt(e.target.value),
                    )
                  }
                  className="w-full max-w-md"
                />
                <div className="flex justify-between max-w-md text-slate-500 text-xs mt-1">
                  <span>1s (High frequency)</span>
                  <span>10s (Low frequency)</span>
                </div>
              </div>

              {/* Camera Feeds */}
              <div>
                <label className="block text-slate-400 text-sm mb-3">
                  Camera Feed Status
                </label>
                <div className="space-y-2 max-w-2xl">
                  {cameraSettings.map((cam) => (
                    <div
                      key={cam.id}
                      className="flex items-center justify-between bg-slate-800/50 rounded-lg p-4"
                    >
                      <div className="flex items-center gap-3">
                        <Camera className="w-5 h-5 text-slate-400" />
                        <div>
                          <div className="text-white">
                            {cam.name}
                          </div>
                          <div className="text-slate-400 text-xs">
                            {cam.id} • ROI:{" "}
                            {cam.roi ? "Configured" : "Not set"}
                          </div>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={cam.enabled}
                          onChange={() =>
                            handleToggleCamera(cam.id)
                          }
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleSaveSettings}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  <Save className="w-4 h-4" />
                  Save Timing Settings
                </button>
              </div>
            </div>
          )}

          {/* Object Categories Tab */}
          {activeTab === "objects" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-white mb-1">
                  Object Category Management
                </h3>
                <p className="text-slate-400 text-sm">
                  Enable or disable detection for specific
                  object types
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 max-w-4xl">
                {objectTypes.map((obj) => (
                  <div
                    key={obj.name}
                    className="flex items-center justify-between bg-slate-800/50 rounded-lg p-4"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">
                        {obj.icon}
                      </span>
                      <div>
                        <div className="text-white">
                          {obj.name}
                        </div>
                        <div className="text-slate-400 text-xs">
                          {obj.enabled
                            ? "Detection active"
                            : "Detection disabled"}
                        </div>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={obj.enabled}
                        onChange={() =>
                          handleToggleObjectType(obj.name)
                        }
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                ))}
              </div>

              <div className="bg-yellow-900/20 border border-yellow-800 rounded-lg p-4 max-w-4xl">
                <p className="text-yellow-300 text-sm">
                  ⚠️ Disabling object types will prevent
                  detection of those items in both live feeds
                  and uploaded videos.
                </p>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleSaveSettings}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  <Save className="w-4 h-4" />
                  Save Object Settings
                </button>
              </div>
            </div>
          )}

          {/* Notifications Tab */}
          {activeTab === "notifications" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-white mb-1">
                  Notification Settings
                </h3>
                <p className="text-slate-400 text-sm">
                  Configure alerts when new lost items are
                  detected
                </p>
              </div>

              <div className="max-w-2xl space-y-4">
                <div className="flex items-center justify-between bg-slate-800/50 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-slate-400" />
                    <div>
                      <div className="text-white">
                        Enable Notifications
                      </div>
                      <div className="text-slate-400 text-xs">
                        Receive alerts when new items are
                        detected
                      </div>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={notificationsEnabled}
                      onChange={(e) =>
                        setNotificationsEnabled(
                          e.target.checked,
                        )
                      }
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                  </label>
                </div>

                <div className="bg-blue-900/20 border border-blue-800 rounded-lg p-4">
                  <p className="text-blue-300 text-sm">
                    🔔 Future feature: Email and SMS
                    notifications will be available in the next
                    update.
                  </p>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleSaveSettings}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  <Save className="w-4 h-4" />
                  Save Notification Settings
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}