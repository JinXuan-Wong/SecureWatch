import { useState } from "react";
import {
  Search,
  Filter,
  MapPin,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Trash2,
  Edit2,
  X,
} from "lucide-react";

export interface LostItem {
  id: string;
  imageUrl: string;
  objectType:
    | "Water Bottle"
    | "Wallet"
    | "ID Card"
    | "Card Holder"
    | "Phone";
  status: "Lost" | "Solved";
  location: string;
  detectionDate: Date;
  source: "Live Detection" | "Uploaded Video";
  videoName?: string;
  notes?: string;
}

const initialItems: LostItem[] = [
  {
    id: "item-001",
    imageUrl:
      "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400",
    objectType: "Water Bottle",
    status: "Lost",
    location: "Block B - GF - Class A",
    detectionDate: new Date(Date.now() - 30 * 60 * 1000),
    source: "Live Detection",
    notes: "Blue water bottle found near desk 12",
  },
  {
    id: "item-002",
    imageUrl:
      "https://images.unsplash.com/photo-1627123424574-724758594e93?w=400",
    objectType: "Wallet",
    status: "Lost",
    location: "Block B - GF - Class G",
    detectionDate: new Date(Date.now() - 2 * 60 * 60 * 1000),
    source: "Uploaded Video",
    videoName:
      "B001G_Parking_Lot_20251205080000_20251205084520_39454535.mp4",
  },
  {
    id: "item-003",
    imageUrl:
      "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400",
    objectType: "Phone",
    status: "Solved",
    location: "Block B - GF - Class A",
    detectionDate: new Date(Date.now() - 5 * 60 * 60 * 1000),
    source: "Live Detection",
    notes: "Owner claimed the phone",
  },
  {
    id: "item-004",
    imageUrl:
      "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400",
    objectType: "ID Card",
    status: "Lost",
    location: "Block B - 1F - Class D",
    detectionDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
    source: "Live Detection",
  },
  {
    id: "item-005",
    imageUrl:
      "https://images.unsplash.com/photo-1614252368965-2e8d4ac7ea53?w=400",
    objectType: "Card Holder",
    status: "Lost",
    location: "Block B - 1F - Class C",
    detectionDate: new Date(Date.now() - 48 * 60 * 60 * 1000),
    source: "Uploaded Video",
    videoName:
      "B100C_Corridor_East_20251205120030_20251205133530_39454534.mp4",
    notes: "Black card holder with multiple cards",
  },
];

interface EditModalProps {
  item: LostItem;
  onSave: (item: LostItem) => void;
  onClose: () => void;
}

function EditModal({ item, onSave, onClose }: EditModalProps) {
  const [editedItem, setEditedItem] = useState(item);

  const handleSave = () => {
    onSave(editedItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-slate-900 border-b border-slate-700 px-6 py-4 flex items-center justify-between">
          <h3 className="text-white">Edit Item Details</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-slate-400 text-sm mb-2">
              Object Type
            </label>
            <select
              value={editedItem.objectType}
              onChange={(e) =>
                setEditedItem({
                  ...editedItem,
                  objectType: e.target
                    .value as LostItem["objectType"],
                })
              }
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
            >
              <option>Water Bottle</option>
              <option>Wallet</option>
              <option>ID Card</option>
              <option>Card Holder</option>
              <option>Phone</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 text-sm mb-2">
              Status
            </label>
            <select
              value={editedItem.status}
              onChange={(e) =>
                setEditedItem({
                  ...editedItem,
                  status: e.target.value as LostItem["status"],
                })
              }
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
            >
              <option>Lost</option>
              <option>Solved</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 text-sm mb-2">
              Location
            </label>
            <input
              type="text"
              value={editedItem.location}
              onChange={(e) =>
                setEditedItem({
                  ...editedItem,
                  location: e.target.value,
                })
              }
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
            />
          </div>

          <div>
            <label className="block text-slate-400 text-sm mb-2">
              Notes
            </label>
            <textarea
              value={editedItem.notes || ""}
              onChange={(e) =>
                setEditedItem({
                  ...editedItem,
                  notes: e.target.value,
                })
              }
              rows={3}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white resize-none"
              placeholder="Add notes about this item..."
            />
          </div>
        </div>

        <div className="sticky bottom-0 bg-slate-900 border-t border-slate-700 px-6 py-4 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

export function LostAndFoundEventsPage() {
  const [items, setItems] = useState<LostItem[]>(initialItems);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<string>("All");
  const [filterStatus, setFilterStatus] =
    useState<string>("All");
  const [selectedItem, setSelectedItem] =
    useState<LostItem | null>(null);
  const [editingItem, setEditingItem] =
    useState<LostItem | null>(null);

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.objectType
        .toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      item.location
        .toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      (item.notes
        ?.toLowerCase()
        .includes(searchQuery.toLowerCase()) ??
        false);
    const matchesType =
      filterType === "All" || item.objectType === filterType;
    const matchesStatus =
      filterStatus === "All" || item.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const handleStatusToggle = (itemId: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === itemId
          ? {
              ...item,
              status:
                item.status === "Lost" ? "Solved" : "Lost",
            }
          : item,
      ),
    );
  };

  const handleDelete = (itemId: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      setItems((prev) =>
        prev.filter((item) => item.id !== itemId),
      );
      setSelectedItem(null);
    }
  };

  const handleEdit = (item: LostItem) => {
    setEditingItem(item);
  };

  const handleSaveEdit = (updatedItem: LostItem) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === updatedItem.id ? updatedItem : item,
      ),
    );
    if (selectedItem?.id === updatedItem.id) {
      setSelectedItem(updatedItem);
    }
  };

  const getObjectIcon = (type: string) => {
    const iconMap: { [key: string]: string } = {
      "Water Bottle": "💧",
      Wallet: "👛",
      "ID Card": "🪪",
      "Card Holder": "💳",
      Phone: "📱",
    };
    return iconMap[type] || "📦";
  };

  const lostCount = items.filter(
    (item) => item.status === "Lost",
  ).length;
  const solvedCount = items.filter(
    (item) => item.status === "Solved",
  ).length;

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      {/* Page Header */}
      <div className="mb-6">
        <h2 className="text-white mb-1">
          Lost & Found Management
        </h2>
        <p className="text-slate-400">
          Track and manage lost items detected in the university
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">
            Total Items
          </div>
          <div className="text-white text-2xl">
            {items.length}
          </div>
        </div>
        <div className="bg-slate-900/50 border border-red-900/30 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">
            Lost Items
          </div>
          <div className="text-red-400 text-2xl">
            {lostCount}
          </div>
        </div>
        <div className="bg-slate-900/50 border border-green-900/30 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">
            Solved
          </div>
          <div className="text-green-400 text-2xl">
            {solvedCount}
          </div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">
            Detection Sources
          </div>
          <div className="text-white text-sm mt-1">
            Live:{" "}
            {
              items.filter((i) => i.source === "Live Detection")
                .length
            }{" "}
            | Upload:{" "}
            {
              items.filter((i) => i.source === "Uploaded Video")
                .length
            }
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search items, locations, or notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Type Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
            >
              <option>All</option>
              <option>Water Bottle</option>
              <option>Wallet</option>
              <option>ID Card</option>
              <option>Card Holder</option>
              <option>Phone</option>
            </select>
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
          >
            <option>All</option>
            <option>Lost</option>
            <option>Solved</option>
          </select>
        </div>
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-3 gap-4">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedItem(item)}
            className="bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden hover:border-blue-500 transition-colors cursor-pointer group"
          >
            {/* Item Image */}
            <div className="relative aspect-video bg-slate-950">
              <img
                src={item.imageUrl}
                alt={item.objectType}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2">
                <div
                  className={`px-2 py-1 rounded text-xs font-medium ${
                    item.status === "Lost"
                      ? "bg-red-500/90 text-white"
                      : "bg-green-500/90 text-white"
                  }`}
                >
                  {item.status}
                </div>
              </div>
              <div className="absolute top-2 right-2">
                <div className="bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-xs text-white">
                  {item.source}
                </div>
              </div>
            </div>

            {/* Item Info */}
            <div className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">
                  {getObjectIcon(item.objectType)}
                </span>
                <h3 className="text-white">
                  {item.objectType}
                </h3>
              </div>

              <div className="space-y-1.5 text-sm">
                <div className="flex items-center gap-2 text-slate-400">
                  <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">
                    {item.location}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <Calendar className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>
                    {item.detectionDate.toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>
                    {item.detectionDate.toLocaleTimeString()}
                  </span>
                </div>
              </div>

              {item.notes && (
                <p className="mt-3 text-slate-400 text-sm line-clamp-2">
                  {item.notes}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredItems.length === 0 && (
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-12 text-center">
          <p className="text-slate-400">
            No items found matching your filters
          </p>
        </div>
      )}

      {/* Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-slate-900 border-b border-slate-700 px-6 py-4 flex items-center justify-between">
              <h3 className="text-white">Item Details</h3>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6">
              {/* Item Image */}
              <img
                src={selectedItem.imageUrl}
                alt={selectedItem.objectType}
                className="w-full aspect-video object-cover rounded-lg mb-6"
              />

              {/* Item Details */}
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="text-slate-400 text-sm">
                    Object Type
                  </label>
                  <div className="text-white mt-1 flex items-center gap-2">
                    <span className="text-2xl">
                      {getObjectIcon(selectedItem.objectType)}
                    </span>
                    {selectedItem.objectType}
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 text-sm">
                    Status
                  </label>
                  <div className="mt-1">
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm ${
                        selectedItem.status === "Lost"
                          ? "bg-red-500/20 text-red-400"
                          : "bg-green-500/20 text-green-400"
                      }`}
                    >
                      {selectedItem.status === "Lost" ? (
                        <AlertCircle className="w-4 h-4" />
                      ) : (
                        <CheckCircle className="w-4 h-4" />
                      )}
                      {selectedItem.status}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 text-sm">
                    Location
                  </label>
                  <div className="text-white mt-1 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-slate-400" />
                    {selectedItem.location}
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 text-sm">
                    Detection Date & Time
                  </label>
                  <div className="text-white mt-1">
                    {selectedItem.detectionDate.toLocaleDateString()}{" "}
                    at{" "}
                    {selectedItem.detectionDate.toLocaleTimeString()}
                  </div>
                </div>
                <div>
                  <label className="text-slate-400 text-sm">
                    Detection Source
                  </label>
                  <div className="text-white mt-1">
                    {selectedItem.source}
                  </div>
                </div>
                {selectedItem.videoName && (
                  <div>
                    <label className="text-slate-400 text-sm">
                      Video File
                    </label>
                    <div className="text-white mt-1 text-sm truncate">
                      {selectedItem.videoName}
                    </div>
                  </div>
                )}
              </div>

              {selectedItem.notes && (
                <div className="mb-6">
                  <label className="text-slate-400 text-sm">
                    Notes
                  </label>
                  <div className="text-white mt-1 bg-slate-800/50 p-3 rounded-lg">
                    {selectedItem.notes}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() =>
                    handleStatusToggle(selectedItem.id)
                  }
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg transition-colors ${
                    selectedItem.status === "Lost"
                      ? "bg-green-600 hover:bg-green-700 text-white"
                      : "bg-red-600 hover:bg-red-700 text-white"
                  }`}
                >
                  {selectedItem.status === "Lost" ? (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      Mark as Solved
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4 h-4" />
                      Mark as Lost
                    </>
                  )}
                </button>
                <button
                  onClick={() => handleEdit(selectedItem)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(selectedItem.id)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingItem && (
        <EditModal
          item={editingItem}
          onSave={handleSaveEdit}
          onClose={() => setEditingItem(null)}
        />
      )}
    </div>
  );
}