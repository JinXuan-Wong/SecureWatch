import { useState } from "react";
import {
  FileText,
  Download,
  Calendar,
  Filter,
  TrendingUp,
  Package,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

interface ReportItem {
  id: string;
  objectType: string;
  status: "Lost" | "Solved";
  location: string;
  detectionDate: Date;
  solvedDate?: Date;
}

const mockReportData: ReportItem[] = [
  {
    id: "001",
    objectType: "Water Bottle",
    status: "Solved",
    location: "B001A - Block B - GF - Class A",
    detectionDate: new Date("2024-12-01"),
    solvedDate: new Date("2024-12-02"),
  },
  {
    id: "002",
    objectType: "Phone",
    status: "Solved",
    location: "B001G - Block B - GF - Class G",
    detectionDate: new Date("2024-12-01"),
    solvedDate: new Date("2024-12-01"),
  },
  {
    id: "003",
    objectType: "Wallet",
    status: "Lost",
    location: "B100A - Block B - 1F - Class A",
    detectionDate: new Date("2024-12-02"),
  },
  {
    id: "004",
    objectType: "ID Card",
    status: "Solved",
    location: "B100D - Block B - 1F - Class D",
    detectionDate: new Date("2024-12-03"),
    solvedDate: new Date("2024-12-04"),
  },
  {
    id: "005",
    objectType: "Water Bottle",
    status: "Lost",
    location: "B001A - Block B - GF - Class A",
    detectionDate: new Date("2024-12-03"),
  },
  {
    id: "006",
    objectType: "Card Holder",
    status: "Solved",
    location: "B001H - Block B - GF - Class H",
    detectionDate: new Date("2024-12-04"),
    solvedDate: new Date("2024-12-05"),
  },
  {
    id: "007",
    objectType: "Phone",
    status: "Lost",
    location: "B001G - Block B - GF - Class G",
    detectionDate: new Date("2024-12-05"),
  },
  {
    id: "008",
    objectType: "Wallet",
    status: "Solved",
    location: "B100A - Block B - 1F - Class A",
    detectionDate: new Date("2024-12-05"),
    solvedDate: new Date("2024-12-06"),
  },
  {
    id: "009",
    objectType: "Water Bottle",
    status: "Solved",
    location: "B001A - Block B - GF - Class A",
    detectionDate: new Date("2024-12-06"),
    solvedDate: new Date("2024-12-07"),
  },
  {
    id: "010",
    objectType: "ID Card",
    status: "Lost",
    location: "B100D - Block B - 1F - Class D",
    detectionDate: new Date("2024-12-07"),
  },
  {
    id: "011",
    objectType: "Phone",
    status: "Solved",
    location: "B001H - Block B - GF - Class H",
    detectionDate: new Date("2024-12-07"),
    solvedDate: new Date("2024-12-08"),
  },
  {
    id: "012",
    objectType: "Card Holder",
    status: "Lost",
    location: "B001G - Block B - GF - Class G",
    detectionDate: new Date("2024-12-08"),
  },
];

export function LostAndFoundReportsPage() {
  const [filterType, setFilterType] = useState<string>("All");
  const [filterStatus, setFilterStatus] =
    useState<string>("All");
  const [startDate, setStartDate] =
    useState<string>("2024-12-01");
  const [endDate, setEndDate] = useState<string>("2024-12-08");

  // Filter data
  const filteredData = mockReportData.filter((item) => {
    const matchesType =
      filterType === "All" || item.objectType === filterType;
    const matchesStatus =
      filterStatus === "All" || item.status === filterStatus;
    const itemDate = item.detectionDate;
    const matchesDate =
      itemDate >= new Date(startDate) &&
      itemDate <= new Date(endDate);
    return matchesType && matchesStatus && matchesDate;
  });

  // Calculate statistics
  const totalItems = filteredData.length;
  const solvedCount = filteredData.filter(
    (item) => item.status === "Solved",
  ).length;
  const lostCount = filteredData.filter(
    (item) => item.status === "Lost",
  ).length;
  const solvedRate =
    totalItems > 0
      ? ((solvedCount / totalItems) * 100).toFixed(1)
      : "0";

  // Most frequent item
  const itemTypeCounts = filteredData.reduce(
    (acc, item) => {
      acc[item.objectType] = (acc[item.objectType] || 0) + 1;
      return acc;
    },
    {} as Record<string, number>,
  );
  const mostFrequentItem =
    Object.entries(itemTypeCounts).sort(
      (a, b) => b[1] - a[1],
    )[0]?.[0] || "N/A";

  // Chart data - Item type frequency
  const itemTypeChartData = Object.entries(itemTypeCounts).map(
    ([name, count]) => ({
      name,
      count,
    }),
  );

  // Chart data - Monthly trend
  const monthlyTrendData = [
    { month: "Jul", items: 8 },
    { month: "Aug", items: 12 },
    { month: "Sep", items: 15 },
    { month: "Oct", items: 10 },
    { month: "Nov", items: 18 },
    { month: "Dec", items: totalItems },
  ];

  // Status distribution for pie chart
  const statusData = [
    { name: "Solved", value: solvedCount, color: "#10b981" },
    { name: "Lost", value: lostCount, color: "#ef4444" },
  ];

  const handleExportPDF = () => {
    alert("Exporting Lost & Found report as PDF...");
  };

  const handleExportExcel = () => {
    alert("Exporting Lost & Found report as Excel...");
  };

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-white mb-1">
              Lost & Found Reports
            </h2>
            <p className="text-slate-400">
              Track and analyze lost & found activity
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportPDF}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Export PDF
            </button>
            <button
              onClick={handleExportExcel}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Export Excel
            </button>
          </div>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <div className="text-slate-400 text-sm">
                Total Items
              </div>
              <div className="text-white text-2xl">
                {totalItems}
              </div>
            </div>
          </div>
        </div>
        <div className="bg-slate-900/50 border border-green-900/30 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <div className="text-slate-400 text-sm">
                Solved Cases
              </div>
              <div className="text-white text-2xl">
                {solvedCount}
              </div>
            </div>
          </div>
        </div>
        <div className="bg-slate-900/50 border border-red-900/30 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <div className="text-slate-400 text-sm">
                Lost Cases
              </div>
              <div className="text-white text-2xl">
                {lostCount}
              </div>
            </div>
          </div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="text-slate-400 text-sm">
                Solved Rate
              </div>
              <div className="text-white text-2xl">
                {solvedRate}%
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Most Frequent Item */}
      <div className="bg-blue-900/20 border border-blue-800 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-3">
          <Package className="w-5 h-5 text-blue-400" />
          <div>
            <div className="text-blue-300 text-sm">
              Most Frequently Lost Item
            </div>
            <div className="text-white">{mostFrequentItem}</div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-4">
          <Filter className="w-4 h-4 text-slate-400" />

          <div className="flex items-center gap-2">
            <label className="text-slate-400 text-sm">
              From:
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm"
            />
          </div>

          <div className="flex items-center gap-2">
            <label className="text-slate-400 text-sm">
              To:
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm"
            />
          </div>

          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
          >
            <option>All</option>
            <option>Water Bottle</option>
            <option>Wallet</option>
            <option>ID Card</option>
            <option>Card Holder</option>
            <option>Phone</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white"
          >
            <option>All</option>
            <option>Lost</option>
            <option>Solved</option>
          </select>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        {/* Item Type Frequency Bar Chart */}
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
          <h3 className="text-white mb-4">
            Item Type Frequency
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={itemTypeChartData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#334155"
              />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1e293b",
                  border: "1px solid #334155",
                  borderRadius: "8px",
                  color: "#fff",
                }}
              />
              <Bar
                dataKey="count"
                fill="#3b82f6"
                radius={[8, 8, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Monthly Trend Line Chart */}
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
          <h3 className="text-white mb-4">Monthly Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyTrendData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="#334155"
              />
              <XAxis dataKey="month" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1e293b",
                  border: "1px solid #334155",
                  borderRadius: "8px",
                  color: "#fff",
                }}
              />
              <Line
                type="monotone"
                dataKey="items"
                stroke="#10b981"
                strokeWidth={3}
                dot={{ fill: "#10b981", r: 6 }}
                activeDot={{ r: 8 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Status Distribution Pie Chart */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6 mb-6">
        <h3 className="text-white mb-4">Status Distribution</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={statusData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) =>
                `${name}: ${(percent * 100).toFixed(0)}%`
              }
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
            >
              {statusData.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.color}
                />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "#1e293b",
                border: "1px solid #334155",
                borderRadius: "8px",
                color: "#fff",
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Historical Data Table */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800">
          <h3 className="text-white">Historical Lost Items</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800/50">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-slate-400 uppercase tracking-wider">
                  Item ID
                </th>
                <th className="px-6 py-3 text-left text-xs text-slate-400 uppercase tracking-wider">
                  Object Type
                </th>
                <th className="px-6 py-3 text-left text-xs text-slate-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs text-slate-400 uppercase tracking-wider">
                  Location
                </th>
                <th className="px-6 py-3 text-left text-xs text-slate-400 uppercase tracking-wider">
                  Detection Date
                </th>
                <th className="px-6 py-3 text-left text-xs text-slate-400 uppercase tracking-wider">
                  Solved Date
                </th>
                <th className="px-6 py-3 text-left text-xs text-slate-400 uppercase tracking-wider">
                  Days to Solve
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredData.map((item) => {
                const daysToSolve = item.solvedDate
                  ? Math.ceil(
                      (item.solvedDate.getTime() -
                        item.detectionDate.getTime()) /
                        (1000 * 60 * 60 * 24),
                    )
                  : null;

                return (
                  <tr
                    key={item.id}
                    className="hover:bg-slate-800/30"
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">
                      #{item.id}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                      {item.objectType}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs ${
                          item.status === "Solved"
                            ? "bg-green-500/20 text-green-400"
                            : "bg-red-500/20 text-red-400"
                        }`}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">
                      {item.location}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">
                      {item.detectionDate.toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">
                      {item.solvedDate
                        ? item.solvedDate.toLocaleDateString()
                        : "-"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">
                      {daysToSolve !== null
                        ? `${daysToSolve} day${daysToSolve !== 1 ? "s" : ""}`
                        : "-"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filteredData.length === 0 && (
          <div className="px-6 py-12 text-center text-slate-400">
            No data found matching the selected filters
          </div>
        )}
      </div>
    </div>
  );
}