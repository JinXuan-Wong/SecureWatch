import { 
  LayoutDashboard, 
  Video, 
  BarChart3, 
  Settings, 
  Users, 
  History,
  Upload,
  LogOut,
  Package,
  FileText
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  onLogout?: () => void;
  currentUser?: { name: string; role: string };
  role: "Admin" | "Security" | "Staff" | "Viewer";
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'live-attire', label: 'Live View (Attire)', icon: Video },
  { id: 'live-lostfound', label: 'Live View (Lost & Found)', icon: Package },
  { id: 'reports', label: 'Reports', icon: FileText },
  { id: 'events', label: 'Events', icon: History },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'upload-video', label: 'Upload Video', icon: Upload },
  { id: 'users', label: 'Users', icon: Users },
];

const allowedByRole: Record<string, string[]> = {
  Admin: ["dashboard","live-attire","live-lostfound","reports","events","settings","upload-video","recordings","users"],
  Security: ["dashboard","live-attire","live-lostfound","reports","events","settings","upload-video","recordings"],
  Staff: ["dashboard","live-attire","live-lostfound","reports","events","settings","upload-video","recordings"],
  Viewer: ["dashboard","live-attire","live-lostfound","reports","events"],
};

export function Sidebar({ currentPage, onPageChange, onLogout, currentUser, role }: SidebarProps) {
  const visibleItems = menuItems.filter((i) =>
    (allowedByRole[role] || []).includes(i.id),
  );
  return (
    <aside className="w-64 h-screen shrink-0 sticky top-0 bg-slate-900 border-r border-slate-800 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Video className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-white">SecureWatch</h2>
            <p className="text-slate-400 text-xs mt-0.5">Pro v2.0</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-1">
          {visibleItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Footer (User + Logout always visible) */}
      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center">
            <span className="text-white">AS</span>
          </div>
      
          <div className="flex-1 min-w-0">
            <div className="text-white text-sm">{currentUser?.name || "Unknown"}</div>
            <div className="text-slate-400 text-xs">{currentUser?.role || ""}</div>
          </div>
      
          <button
            onClick={onLogout}
            className="text-slate-400 hover:text-white"
            title="Logout"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>
    </aside>
  );
}