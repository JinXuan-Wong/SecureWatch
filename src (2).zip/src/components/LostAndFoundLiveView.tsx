import { useEffect, useMemo, useRef, useState } from "react";
import { Circle, Eye, Maximize2, Package, AlertTriangle } from "lucide-react";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

type ItemType = "bag" | "bottle" | "phone" | "wallet" | "unknown";

interface Detection {
  id: string;
  x: number;      // percent
  y: number;      // percent
  width: number;  // percent
  height: number; // percent
  label: string;  // e.g. "Backpack", "Bottle"
  itemType?: ItemType;
  confidence?: number;
}

interface Camera {
  id: string;
  name: string;
  location: string;
  mode?: "attire" | "lost-found";
}

async function fetchCameras(): Promise<Camera[]> {
  const res = await fetch(`${API_BASE}/api/cameras`);
  if (!res.ok) throw new Error("Failed to load cameras");
  return res.json();
}

async function fetchDetections(camId: string): Promise<{ ts: number; fps: number; resolution: [number, number]; detections: Detection[] }> {
  const res = await fetch(`${API_BASE}/api/cameras/${camId}/detections`);
  if (!res.ok) throw new Error("Failed to load detections");
  return res.json();
}

function boxStyle(itemType?: ItemType) {
  switch (itemType) {
    case "phone":
      return "border-cyan-400 bg-cyan-400/10";
    case "wallet":
      return "border-emerald-400 bg-emerald-400/10";
    case "bottle":
      return "border-yellow-400 bg-yellow-400/10";
    case "bag":
      return "border-purple-400 bg-purple-400/10";
    default:
      return "border-slate-400 bg-slate-400/10";
  }
}

function badgeStyle(itemType?: ItemType) {
  switch (itemType) {
    case "phone":
      return "bg-cyan-500 text-black";
    case "wallet":
      return "bg-emerald-500 text-black";
    case "bottle":
      return "bg-yellow-500 text-black";
    case "bag":
      return "bg-purple-500 text-white";
    default:
      return "bg-slate-700 text-white";
  }
}

export function LostAndFoundLiveView() {
  const [time, setTime] = useState(new Date());
  const [cameras, setCameras] = useState<Camera[]>([]);
  const [camDetections, setCamDetections] = useState<Record<string, Detection[]>>({});
  const [camMeta, setCamMeta] = useState<Record<string, { fps: number; resolution: [number, number] }>>({});
  const aliveRef = useRef(true);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    aliveRef.current = true;
    (async () => {
      try {
        const list = await fetchCameras();
        const lfCams = list.filter((c) => !c.mode || c.mode === "lost-found");
        if (aliveRef.current) setCameras(lfCams);
      } catch (e) {
        console.error(e);
      }
    })();
    return () => {
      aliveRef.current = false;
    };
  }, []);

  useEffect(() => {
    if (!cameras.length) return;

    let stopped = false;

    const pollOnce = async () => {
      try {
        const results = await Promise.all(
          cameras.map(async (cam) => {
            const d = await fetchDetections(cam.id);
            return { camId: cam.id, data: d };
          })
        );

        if (stopped) return;

        const nextDet: Record<string, Detection[]> = {};
        const nextMeta: Record<string, { fps: number; resolution: [number, number] }> = {};

        for (const r of results) {
          nextDet[r.camId] = r.data.detections ?? [];
          nextMeta[r.camId] = {
            fps: r.data.fps ?? 0,
            resolution: r.data.resolution ?? [0, 0],
          };
        }

        setCamDetections(nextDet);
        setCamMeta(nextMeta);
      } catch (e) {
        console.warn("poll detections failed:", e);
      }
    };

    pollOnce();
    const t = setInterval(pollOnce, 1000);
    return () => {
      stopped = true;
      clearInterval(t);
    };
  }, [cameras]);

  const totalItems = useMemo(() => {
    return cameras.reduce((sum, c) => sum + (camDetections[c.id]?.length ?? 0), 0);
  }, [cameras, camDetections]);

  const bagCount = useMemo(() => {
    return cameras.reduce((sum, c) => sum + (camDetections[c.id]?.filter((d) => d.itemType === "bag").length ?? 0), 0);
  }, [cameras, camDetections]);

  const phoneWalletCount = useMemo(() => {
    return cameras.reduce(
      (sum, c) =>
        sum + (camDetections[c.id]?.filter((d) => d.itemType === "phone" || d.itemType === "wallet").length ?? 0),
      0
    );
  }, [cameras, camDetections]);

  return (
    <main className="flex-1 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-white mb-1">Live View - Lost &amp; Found Monitoring</h2>
            <p className="text-slate-400">Real-time detection of lost items in monitored areas</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-slate-400">
              <Circle className="w-2 h-2 fill-green-500 text-green-500 animate-pulse" />
              <span>Live</span>
            </div>
            <div className="text-slate-400">{time.toLocaleTimeString()}</div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Active Cameras</div>
          <div className="text-white text-2xl">{cameras.length}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Detected Items</div>
          <div className="text-white text-2xl">{totalItems}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Bags</div>
          <div className="text-purple-400 text-2xl">{bagCount}</div>
        </div>
        <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
          <div className="text-slate-400 text-sm mb-1">Phone/Wallet</div>
          <div className="text-cyan-400 text-2xl">{phoneWalletCount}</div>
        </div>
      </div>

      {/* Camera Grid */}
      <div className="grid grid-cols-2 gap-4">
        {cameras.map((camera) => {
          const detections = camDetections[camera.id] ?? [];
          const meta = camMeta[camera.id] ?? { fps: 0, resolution: [0, 0] as [number, number] };

          return (
            <div key={camera.id} className="bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden">
              <div className="bg-slate-800/50 px-4 py-3 border-b border-slate-700">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      {camera.name}
                    </div>
                    <div className="text-slate-400 text-sm">{camera.location}</div>
                  </div>

                  <div className="flex items-center gap-2">
                    {detections.length > 0 && (
                      <div className="flex items-center gap-1.5 bg-slate-700/40 text-slate-200 px-2 py-1 rounded text-xs">
                        <Package className="w-3 h-3" />
                        {detections.length} item{detections.length !== 1 ? "s" : ""}
                      </div>
                    )}
                    <button className="p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-white transition-colors">
                      <Maximize2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="relative aspect-video bg-slate-950 overflow-hidden">
                <img
                  src={`${API_BASE}/api/cameras/${camera.id}/stream`}
                  alt={`${camera.name} stream`}
                  className="absolute inset-0 w-full h-full object-cover"
                />

                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-xs">
                    <Circle className="w-2 h-2 fill-red-500 text-red-500 animate-pulse" />
                    <span className="text-white">REC</span>
                  </div>
                  <div className="bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-xs text-white">
                    {time.toLocaleTimeString()}
                  </div>
                </div>

                {detections.map((d) => (
                  <div
                    key={d.id}
                    className={`absolute border-2 ${boxStyle(d.itemType)} pointer-events-none`}
                    style={{
                      left: `${d.x}%`,
                      top: `${d.y}%`,
                      width: `${d.width}%`,
                      height: `${d.height}%`,
                    }}
                  >
                    <div className={`absolute -top-6 left-0 ${badgeStyle(d.itemType)} px-2 py-0.5 rounded text-xs whitespace-nowrap shadow-lg`}>
                      <div className="flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        {d.label}
                      </div>
                    </div>
                  </div>
                ))}

                {detections.length === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-blue-500/10 border border-blue-500/30 text-blue-300 px-4 py-2 rounded-lg text-sm">
                      No items detected
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-slate-800/30 px-4 py-2 border-t border-slate-700">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>AI Detection: Active</span>
                  <span>FPS: {meta.fps}</span>
                  <span>
                    Resolution: {meta.resolution?.[0]}x{meta.resolution?.[1]}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </main>
  );
}
