// App.tsx
import { useEffect, useRef, useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { CameraFeed } from "./components/CameraFeed";
import { ControlBar } from "./components/ControlBar";
import { UploadVideoPage } from "./components/UploadVideoPage";
import { EventsPage } from "./components/EventsPage";
import { SettingsPage } from "./components/SettingsPage";
import { ReportsPage } from "./components/ReportsPage";
import { LoginPage } from "./components/LoginPage";
import { UsersPage } from "./components/userpage";
import { api, getToken, setToken } from "./api/apiHelper";
import {
  Bell,
  AlertTriangle,
  Package,
  ShieldAlert,
} from "lucide-react";
import { LostFoundDashboard } from "./components/LostAndFoundDashboard";
import { AttireDashboard } from "./components/AttireComplianceDashboard";
import { lostFoundCameras } from "./components/lostFoundCameras";
import { AttireComplianceLiveView } from "./components/AttireComplianceLiveView";
import { LostAndFoundLiveView } from "./components/LostAndFoundLiveView";

export interface Camera {
  id: string;
  name: string;
  location: string;
  status: "online" | "offline" | "warning";
  imageUrl: string;
  recording: boolean;
}

export interface Alert {
  id: string;
  cameraId: string;
  cameraName: string;
  type:
    | "motion"
    | "intrusion"
    | "offline"
    | "lost-found"
    | "attire-violation";
  timestamp: Date;
  severity: "low" | "medium" | "high";
  message: string;
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [me, setMe] = useState<any>(null);

  type AttireToast = {
    id: string;
    title: string;
    message: string;
    createdAt: number;
  };

  const [attireToasts, setAttireToasts] = useState<AttireToast[]>([]);
  const [unreadAttireNotifs, setUnreadAttireNotifs] = useState(0);
  const [notifConfig, setNotifConfig] = useState<any>(null);
  const notifConfigRef = useRef<any>(null);
  async function refreshNotifConfig() {
    try {
      const token = getToken();
      if (!token) return;

      const base =
        (import.meta as any).env?.VITE_API_BASE_URL?.replace(/\/$/, "") ||
        "http://127.0.0.1:8000";

      const r = await fetch(`${base}/api/attire/notifications`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!r.ok) return;

      const data = await r.json();
      setNotifConfig(data.config);
    } catch {}
  }

  const role = (me?.role || "Viewer") as "Admin" | "Security" | "Staff" | "Viewer";
  const allowedPagesByRole: Record<typeof role, string[]> = {
    Admin: ["dashboard","live-attire","live-lostfound","reports","events","settings","upload-video","users"],
    Security: ["dashboard","live-attire","live-lostfound","reports","events","settings","upload-video"],
    Staff: ["dashboard","live-attire","live-lostfound","reports","events","settings","upload-video"],
    Viewer: ["dashboard","live-attire","live-lostfound","reports","events"],
  };

  const canAccessPage = (page: string) => allowedPagesByRole[role].includes(page);
  const canExportReports = role === "Admin"; //only admin can export

  const [cameras, setCameras] = useState<Camera[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [monitoringMode, setMonitoringMode] = useState<"lost-found" | "attire">("lost-found");
  const [activeSources, setActiveSources] = useState<number>(0);
  const [attireTotalSources, setAttireTotalSources] = useState<number>(() => {
  const v = Number(localStorage.getItem("attire:totalSources") || 0);
    return Number.isFinite(v) && v >= 0 ? v : 0;
  });
  const notifyAudioRef = useRef<HTMLAudioElement | null>(null);
  useEffect(() => {
    notifyAudioRef.current = new Audio("/sounds/notify.wav");
    notifyAudioRef.current.preload = "auto";
  }, []);

  useEffect(() => {
    const unlock = () => {
      const a = notifyAudioRef.current;
      if (!a) return;

      // Try to play once to unlock audio context
      a.play()
        .then(() => {
          a.pause();
          a.currentTime = 0;
        })
        .catch(() => {});

      window.removeEventListener("pointerdown", unlock);
    };

    window.addEventListener("pointerdown", unlock);

    return () => {
      window.removeEventListener("pointerdown", unlock);
    };
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;

    // initial load after login
    refreshNotifConfig();

    const onCfgChanged = (e: StorageEvent | Event) => {
      // other tabs => StorageEvent with key
      if (e instanceof StorageEvent) {
        if (e.key !== "attire:notifCfgVer") return;
      }
      // same tab => you dispatch new Event("storage") (no key) => allow it
      refreshNotifConfig();
    };

    window.addEventListener("storage", onCfgChanged as any);
    return () => window.removeEventListener("storage", onCfgChanged as any);
  }, [isAuthenticated]);

  useEffect(() => {
    const syncNavFromStorage = () => {
      const p = localStorage.getItem("nav:lastPage");
      if (!p) return;
      setCurrentPage(p);

      // keep monitoring mode consistent
      if (p === "live-attire") setMonitoringMode("attire");
      if (p === "live-lostfound") setMonitoringMode("lost-found");
    };

    // initial load (optional)
    syncNavFromStorage();

    // your UploadVideoPage dispatches: window.dispatchEvent(new Event("storage"))
    window.addEventListener("storage", syncNavFromStorage);

    return () => window.removeEventListener("storage", syncNavFromStorage);
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;
    if (!canAccessPage(currentPage)) {
      setCurrentPage("dashboard");
      localStorage.setItem("nav:lastPage", "dashboard");
    }
  }, [currentPage, isAuthenticated, role]);

  useEffect(() => {
    const refreshTotal = () => {
      const v = Number(localStorage.getItem("attire:totalSources") || 0);
      setAttireTotalSources(Number.isFinite(v) && v >= 0 ? v : 0);
    };

    refreshTotal();
    window.addEventListener("storage", refreshTotal);
    return () => window.removeEventListener("storage", refreshTotal);
  }, []);

  useEffect(() => {
    const activeModule: "lost-found" | "attire" =
      currentPage === "live-attire"
        ? "attire"
        : currentPage === "live-lostfound"
        ? "lost-found"
        : monitoringMode;

    const key =
      activeModule === "attire"
        ? "attire:enabledCameraIds"
        : "lostfound:enabledCameraIds";

    const readCount = () => {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) return 0;
        const ids = JSON.parse(raw);
        return Array.isArray(ids) ? ids.length : 0;
      } catch {
        return 0;
      }
    };

    const refresh = () => setActiveSources(readCount());
    refresh();

    window.addEventListener("storage", refresh);
    return () => window.removeEventListener("storage", refresh);
  }, [currentPage, monitoringMode]);

  useEffect(() => {
    (async () => {
      if (!getToken()) return;

      try {
        const r = await api<{ user: any }>("/api/auth/me");
        setMe(r.user);
        setIsAuthenticated(true);
      } catch {
        setToken("");
        setIsAuthenticated(false);
        setMe(null);
      }
    })();
  }, []);
  
  useEffect(() => {
    if (!isAuthenticated) return;

    const token = getToken();
    if (!token) return;

    const base =
      (import.meta as any).env?.VITE_API_BASE_URL?.replace(/\/$/, "") ||
      "http://127.0.0.1:8000";

    const es = new EventSource(
      `${base}/api/attire/notifications/stream?token=${encodeURIComponent(token)}`
    );

    es.addEventListener("config", (ev: any) => {
      try {
        setNotifConfig(JSON.parse(ev.data));
      } catch {}
    });

    es.addEventListener("notify", (ev: any) => {
      try {
        const cfg = notifConfigRef.current;
        if (cfg && cfg.enabled === false) return; // disabled => do nothing

        const n = JSON.parse(ev.data);

        const title = `Attire Violation: ${String(n.violation_type || "").toUpperCase()}`;
        const msg = `${n.source_name || n.source_id || "Unknown source"} • ${new Date().toLocaleTimeString()}`;

        const toastId = n.id || `${Date.now()}-${Math.random()}`;

        setAttireToasts((prev) =>
          [
            {
              id: toastId,
              title,
              message: msg,
              createdAt: Date.now(),
            },
            ...prev,
          ].slice(0, 5)
        );

        setUnreadAttireNotifs((x) => x + 1);

        if (cfg?.play_sound) {
          const a = notifyAudioRef.current;
          if (a) {
            try {
              a.currentTime = 0; // rewind so rapid alerts still play
              a.play().catch(() => {});
            } catch {}
          }
        }
      } catch {}
    });

    return () => es.close();
  }, [isAuthenticated]);

  useEffect(() => {
    const sec = notifConfig?.toast_sec ?? 6;
    if (!attireToasts.length) return;

    const t = window.setTimeout(() => {
      setAttireToasts((prev) => prev.slice(0, -1)); // remove oldest
    }, sec * 1000);

    return () => window.clearTimeout(t);
  }, [attireToasts, notifConfig]);

  useEffect(() => {
    notifConfigRef.current = notifConfig;
  }, [notifConfig]);

  useEffect(() => {
    if (currentPage === "events") setUnreadAttireNotifs(0);
  }, [currentPage]);

  const handleLogin = (user: any) => {
    setMe(user);
    setIsAuthenticated(true);
  };

  const handleLogout = async () => {
    try {
      await api("/api/auth/logout", { method: "POST" });
    } catch {
      // ignore logout errors
    }

    setToken("");
    setMe(null);
    setIsAuthenticated(false);
    setCurrentPage("dashboard");
  };

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  const handleRecordingToggle = (cameraId: string) => {
    setCameras((prev) =>
      prev.map((cam) =>
        cam.id === cameraId
          ? { ...cam, recording: !cam.recording }
          : cam,
      ),
    );
  };

  const handleDismissAlert = (alertId: string) => {
    setAlerts((prev) =>
      prev.filter((alert) => alert.id !== alertId),
    );
  };

  // Get current alerts based on monitoring mode
  const getCurrentAlerts = () => {
    // If don't have a alerts yet, keep it empty for dashboard/live pages.
    if (
      currentPage === "dashboard" ||
      currentPage === "live-attire" ||
      currentPage === "live-lostfound"
    ) {
      return [];
    }

    return alerts;
  };

  const currentAlerts = getCurrentAlerts();

  // which module is currently relevant for the header?
  const activeModule: "lost-found" | "attire" =
    currentPage === "live-attire"
      ? "attire"
      : currentPage === "live-lostfound"
      ? "lost-found"
      : monitoringMode;
      
  const totalSources =
    activeModule === "attire" ? attireTotalSources : lostFoundCameras.length;

  const online = activeSources; // active in live view
  const warnings = activeModule === "attire" ? unreadAttireNotifs : currentAlerts.length; // active violations
  const offline = Math.max(0, totalSources - online); // remaining not active

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return (
          <>
            <main className="flex-1 p-6 overflow-y-auto overflow-x-hidden min-w-0">
              {monitoringMode === "lost-found" && <ControlBar />}

              {monitoringMode === "lost-found" ? (
                <LostFoundDashboard
                  cameras={lostFoundCameras}
                  selectedCamera={selectedCamera}
                  onSelectCamera={setSelectedCamera}
                  onRecordingToggle={handleRecordingToggle}
                />
              ) : (
                <AttireDashboard
                  cameras={cameras}
                  selectedCamera={selectedCamera}
                  onSelectCamera={setSelectedCamera}
                  onRecordingToggle={handleRecordingToggle}
                />
              )}
            </main>
          </>
        );
      case "live-attire":
        return <AttireComplianceLiveView />;
      case "live-lostfound":
        return <LostAndFoundLiveView />;
      case "events":
        return <EventsPage />;
      case "users":
        return <UsersPage />;
      case "settings":
        return <SettingsPage />;
      case "reports":
        return <ReportsPage canExport={canExportReports} />;
      case "upload-video":
        return <UploadVideoPage />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex">
      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onPageChange={(page) => {
          if (!canAccessPage(page)) return; // block
          setCurrentPage(page);
          localStorage.setItem("nav:lastPage", page); // keep consistent
          if (page === "live-attire") setMonitoringMode("attire");
          if (page === "live-lostfound") setMonitoringMode("lost-found");
        }}
        onLogout={handleLogout}
        currentUser={me ? { name: me.name ?? "User", role: me.role ?? "" } : undefined}
        role={role}   // pass down (you'll add this prop)
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-white">
                  CCTV Monitoring System
                </h1>
                <p className="text-slate-400 mt-1">
                  Real-time security surveillance
                </p>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <div className="text-slate-400">
                    {currentTime.toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </div>
                  <div className="text-white mt-1">
                    {currentTime.toLocaleTimeString("en-US", {
                      hour12: false,
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Monitoring Mode Tabs - Only show on dashboard */}
            {currentPage === "dashboard" && (
              <div className="mt-4 flex items-center gap-2 bg-slate-800/30 p-1 rounded-lg w-fit">
                <button
                  onClick={() => setMonitoringMode("lost-found")}
                  className={`px-6 py-2 rounded-md transition-colors ${
                    monitoringMode === "lost-found"
                      ? "bg-blue-600 text-white"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  Lost & Found
                </button>

                <button
                  onClick={() => setMonitoringMode("attire")}
                  className={`px-6 py-2 rounded-md transition-colors ${
                    monitoringMode === "attire"
                      ? "bg-blue-600 text-white"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  Attire Compliance
                </button>
              </div>
            )}

            {/* Status Bar */}
            <div className="mt-4 grid grid-cols-3 gap-4">
              <div className="bg-slate-800/50 rounded-lg px-4 py-3 border border-slate-700">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Online</span>
                  <span className="text-green-400">
                    {online}/{totalSources}
                  </span>
                </div>
              </div>
              <div className="bg-slate-800/50 rounded-lg px-4 py-3 border border-slate-700">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">
                    Warnings
                  </span>
                  <span className="text-yellow-400">
                    {warnings}
                  </span>
                </div>
              </div>
              <div className="bg-slate-800/50 rounded-lg px-4 py-3 border border-slate-700">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">
                    Offline
                  </span>
                  <span className="text-red-400">
                    {offline}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="flex flex-1 overflow-hidden min-w-0">
          {renderPage()}
        </div>
      </div>

      {/* Toast overlay */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] space-y-3 w-[22rem]">
        {attireToasts.map((t) => (
          <div
            key={t.id}
            role="button"
            tabIndex={0}
            onClick={() => {
              setCurrentPage("events");
              localStorage.setItem("nav:lastPage", "events");
              setAttireToasts((prev) => prev.filter((x) => x.id !== t.id)); // optional: auto close
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                setCurrentPage("events");
                localStorage.setItem("nav:lastPage", "events");
              }
            }}
            className="cursor-pointer select-none bg-slate-900 border border-slate-700 rounded-lg shadow-lg p-3 hover:border-slate-500 transition"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-white text-sm font-semibold truncate">{t.title}</div>
                <div className="text-slate-300 text-xs mt-1 truncate">{t.message}</div>
              </div>

              <button
                className="text-slate-400 hover:text-white shrink-0"
                onClick={(e) => {
                  e.stopPropagation(); // ✅ don't navigate
                  setAttireToasts((prev) => prev.filter((x) => x.id !== t.id));
                }}
              >
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}